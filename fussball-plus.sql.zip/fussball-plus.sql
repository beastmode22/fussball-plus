-- MySQL dump 10.17  Distrib 10.3.22-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: fussball-plus
-- ------------------------------------------------------
-- Server version	10.3.22-MariaDB-1:10.3.22+maria~bionic

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `spielerwerte`
--

DROP TABLE IF EXISTS `spielerwerte`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `spielerwerte` (
  `SpielerWertID` int(255) NOT NULL AUTO_INCREMENT,
  `Name` varchar(512) NOT NULL,
  `Athletik` int(255) NOT NULL,
  `Balance` int(255) NOT NULL,
  `Koordination` int(255) NOT NULL,
  `Stabi` int(255) NOT NULL,
  `Dribbling` int(255) NOT NULL,
  `EngesDribbling` int(255) NOT NULL,
  `TempoDribbling` int(255) NOT NULL,
  `Finten` int(255) NOT NULL,
  `EinsGegenEins` int(255) NOT NULL,
  `Passen` int(255) NOT NULL,
  `KurzPass` int(255) NOT NULL,
  `LangPass` int(255) NOT NULL,
  `FirstTouch` int(255) NOT NULL,
  `Ballkontrolle` int(255) NOT NULL,
  `Jonglieren` int(255) NOT NULL,
  `BallubungBoden` int(255) NOT NULL,
  `BallubungWurf` int(255) NOT NULL,
  `Schuss` int(255) NOT NULL,
  `Fernschuss` int(255) NOT NULL,
  `Abschluss` int(255) NOT NULL,
  `Volleys` int(255) NOT NULL,
  `ProfilBild` varchar(512) NOT NULL,
  `ProfilName` varchar(512) NOT NULL,
  PRIMARY KEY (`SpielerWertID`)
) ENGINE=InnoDB AUTO_INCREMENT=47 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `spielerwerte`
--

LOCK TABLES `spielerwerte` WRITE;
/*!40000 ALTER TABLE `spielerwerte` DISABLE KEYS */;
INSERT INTO `spielerwerte` VALUES (16,'Joni',59,73,57,49,76,92,97,85,33,73,99,53,68,73,93,77,49,49,49,65,33,'https://www.fussball-plus.de/ProfilBildIcons/Fu%C3%9Fballcartoon7.jpg','Joni'),(46,'Abel',25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,25,'https://www.fussball-plus.de/ProfilBildIcons/Fu%C3%9Fballcartoon5.jpg','Abel');
/*!40000 ALTER TABLE `spielerwerte` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trainings`
--

DROP TABLE IF EXISTS `trainings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trainings` (
  `Name` varchar(512) CHARACTER SET utf8mb4 NOT NULL,
  `Zeit` int(255) NOT NULL,
  `Rating` int(255) NOT NULL,
  `Schwerpunkt` varchar(512) CHARACTER SET utf8mb4 NOT NULL,
  `Zeichnung` varchar(512) NOT NULL,
  PRIMARY KEY (`Name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trainings`
--

LOCK TABLES `trainings` WRITE;
/*!40000 ALTER TABLE `trainings` DISABLE KEYS */;
INSERT INTO `trainings` VALUES ('Ajax-Kreisel',15,7,'Passübung: Beidseitigkeit','Zeichnung:Ajax-Kreisel');
/*!40000 ALTER TABLE `trainings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `trickwerte`
--

DROP TABLE IF EXISTS `trickwerte`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `trickwerte` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `Name` varchar(512) NOT NULL,
  `AK1` int(255) NOT NULL,
  `AK3` int(255) NOT NULL,
  `AK5` int(255) NOT NULL,
  `LR10` int(255) NOT NULL,
  `LR20` int(255) NOT NULL,
  `LR50` int(255) NOT NULL,
  `T2` int(255) NOT NULL,
  `T4` int(255) NOT NULL,
  `T7` int(255) NOT NULL,
  `K3` int(255) NOT NULL,
  `K6` int(255) NOT NULL,
  `K9` int(255) NOT NULL,
  `ATW` int(255) NOT NULL,
  `BA` int(255) NOT NULL,
  `NL` int(255) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=58 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `trickwerte`
--

LOCK TABLES `trickwerte` WRITE;
/*!40000 ALTER TABLE `trickwerte` DISABLE KEYS */;
INSERT INTO `trickwerte` VALUES (16,'Joni',1,1,1,1,1,1,1,1,1,1,1,1,1,1,1),(17,'Vali',0,0,0,0,0,0,1,0,0,0,0,0,0,0,0),(18,'Gabi',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(19,'Ambros',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(20,'Manfred',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(21,'dumm',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(22,'Torsten',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(23,'test',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(24,'wolfgang',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(25,'wolfgang2',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(35,'test1',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(36,'Jerry',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(37,'Nick',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(38,'Benni',1,0,0,1,0,0,1,0,0,0,0,0,0,0,0),(39,'Lukas',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(40,'Julian',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(41,'Kürsat',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(42,'Konsti',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(43,'Güven',1,0,0,0,1,0,0,0,0,0,0,0,0,0,0),(44,'Jonas',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(45,'Junis',0,0,1,0,1,1,1,0,0,1,0,0,1,1,0),(46,'Ben',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(47,'Luca',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(48,'Abdulla',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(49,'Abdullah',0,0,0,0,0,0,1,0,0,0,0,0,0,0,0),(50,'Alper',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(51,'TestAbel',1,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(52,'TestGabri',1,0,0,1,0,0,1,0,0,0,0,0,0,0,0),(53,'TestJerry',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(54,'Gabri',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(55,'Ömer',1,0,0,1,1,1,1,0,0,1,1,0,0,0,0),(56,'Julian',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0),(57,'Eren',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0);
/*!40000 ALTER TABLE `trickwerte` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `ID` int(255) NOT NULL AUTO_INCREMENT,
  `Name` varchar(512) NOT NULL,
  `Password` varchar(512) NOT NULL,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=71 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (26,'Joni','$2y$10$nKaX9QLT28.1Z8.HIw7eE.NhM0sn.GVUkx3d/QsTlc1G1IFdUHOkC'),(70,'Abel','$2y$10$.jz.EWjHFbx4rJm5uDqhIuft7FT2Cjgr0xojlsgtOlmu2RJBYXJEO');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'fussball-plus'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-02-16 15:40:22
